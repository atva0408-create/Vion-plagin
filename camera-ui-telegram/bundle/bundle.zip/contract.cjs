"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// contract.ts
var contract_exports = {};
__export(contract_exports, {
  contract: () => contract,
  default: () => contract_default
});
module.exports = __toCommonJS(contract_exports);

// node_modules/@camera.ui/sdk/dist/plugin/api.js
var API_EVENT;
(function(API_EVENT2) {
  API_EVENT2["FINISH_LAUNCHING"] = "finishLaunching";
  API_EVENT2["SHUTDOWN"] = "shutdown";
})(API_EVENT || (API_EVENT = {}));

// node_modules/@camera.ui/sdk/dist/plugin/contract.js
var PluginRole;
(function(PluginRole2) {
  PluginRole2["Hub"] = "hub";
  PluginRole2["SensorProvider"] = "sensorProvider";
  PluginRole2["CameraController"] = "cameraController";
  PluginRole2["CameraAndSensorProvider"] = "cameraAndSensorProvider";
  PluginRole2["Service"] = "service";
})(PluginRole || (PluginRole = {}));
var PluginInterface;
(function(PluginInterface2) {
  PluginInterface2["MotionDetection"] = "MotionDetection";
  PluginInterface2["ObjectDetection"] = "ObjectDetection";
  PluginInterface2["AudioDetection"] = "AudioDetection";
  PluginInterface2["FaceDetection"] = "FaceDetection";
  PluginInterface2["LicensePlateDetection"] = "LicensePlateDetection";
  PluginInterface2["ClassifierDetection"] = "ClassifierDetection";
  PluginInterface2["ClipDetection"] = "ClipDetection";
  PluginInterface2["FaceEmbedding"] = "FaceEmbedding";
  PluginInterface2["PersonEmbedding"] = "PersonEmbedding";
  PluginInterface2["Segmentation"] = "Segmentation";
  PluginInterface2["DiscoveryProvider"] = "DiscoveryProvider";
  PluginInterface2["SensorDiscovery"] = "SensorDiscovery";
  PluginInterface2["NVR"] = "NVR";
  PluginInterface2["Notifier"] = "Notifier";
  PluginInterface2["OAuthCapable"] = "OAuthCapable";
  PluginInterface2["OAuthDeviceFlow"] = "OAuthDeviceFlow";
  PluginInterface2["OAuthAuthCodeFlow"] = "OAuthAuthCodeFlow";
  PluginInterface2["OAuthClientCredentials"] = "OAuthClientCredentials";
  PluginInterface2["AssistantTools"] = "AssistantTools";
  PluginInterface2["AssistantModels"] = "AssistantModels";
})(PluginInterface || (PluginInterface = {}));
var PluginCapability;
(function(PluginCapability2) {
  PluginCapability2["PublishNotifications"] = "publishNotifications";
})(PluginCapability || (PluginCapability = {}));

// node_modules/@camera.ui/sdk/dist/sensor/base.js
var SensorType;
(function(SensorType2) {
  SensorType2["Motion"] = "motion";
  SensorType2["Object"] = "object";
  SensorType2["Audio"] = "audio";
  SensorType2["Face"] = "face";
  SensorType2["FaceEmbedder"] = "faceEmbedder";
  SensorType2["PersonEmbedder"] = "personEmbedder";
  SensorType2["Segmenter"] = "segmenter";
  SensorType2["LicensePlate"] = "licensePlate";
  SensorType2["Classifier"] = "classifier";
  SensorType2["Clip"] = "clip";
  SensorType2["ObjectAssist"] = "objectAssist";
  SensorType2["Contact"] = "contact";
  SensorType2["Temperature"] = "temperature";
  SensorType2["Humidity"] = "humidity";
  SensorType2["Occupancy"] = "occupancy";
  SensorType2["Smoke"] = "smoke";
  SensorType2["Leak"] = "leak";
  SensorType2["Gas"] = "gas";
  SensorType2["CarbonMonoxide"] = "carbonMonoxide";
  SensorType2["Heat"] = "heat";
  SensorType2["Cold"] = "cold";
  SensorType2["Vibration"] = "vibration";
  SensorType2["Tamper"] = "tamper";
  SensorType2["Problem"] = "problem";
  SensorType2["Power"] = "power";
  SensorType2["Illuminance"] = "illuminance";
  SensorType2["CarbonDioxide"] = "carbonDioxide";
  SensorType2["Light"] = "light";
  SensorType2["Siren"] = "siren";
  SensorType2["Switch"] = "switch";
  SensorType2["Lock"] = "lock";
  SensorType2["PTZ"] = "ptz";
  SensorType2["SecuritySystem"] = "securitySystem";
  SensorType2["Garage"] = "garage";
  SensorType2["Doorbell"] = "doorbell";
  SensorType2["Battery"] = "battery";
})(SensorType || (SensorType = {}));
var SensorCategory;
(function(SensorCategory2) {
  SensorCategory2["Sensor"] = "sensor";
  SensorCategory2["Control"] = "control";
  SensorCategory2["Trigger"] = "trigger";
  SensorCategory2["Info"] = "info";
})(SensorCategory || (SensorCategory = {}));

// node_modules/@camera.ui/sdk/dist/plugin/notifier.js
var Severity;
(function(Severity2) {
  Severity2["Info"] = "info";
  Severity2["Warn"] = "warn";
  Severity2["Error"] = "error";
  Severity2["Critical"] = "critical";
})(Severity || (Severity = {}));

// node_modules/@camera.ui/sdk/dist/sensor/meta.js
var SensorDomain;
(function(SensorDomain2) {
  SensorDomain2["Binary"] = "binary";
  SensorDomain2["Measurement"] = "measurement";
  SensorDomain2["Switch"] = "switch";
  SensorDomain2["Light"] = "light";
  SensorDomain2["Siren"] = "siren";
  SensorDomain2["Lock"] = "lock";
  SensorDomain2["Cover"] = "cover";
  SensorDomain2["Alarm"] = "alarm";
})(SensorDomain || (SensorDomain = {}));
function defineSensor(meta) {
  return meta;
}

// node_modules/@camera.ui/sdk/dist/sensor/audio.js
var AudioProperty;
(function(AudioProperty2) {
  AudioProperty2["Detected"] = "detected";
  AudioProperty2["Detections"] = "detections";
  AudioProperty2["Decibels"] = "decibels";
  AudioProperty2["LastTriggered"] = "lastTriggered";
})(AudioProperty || (AudioProperty = {}));
var audioMeta = defineSensor({
  type: SensorType.Audio,
  category: SensorCategory.Sensor,
  assignmentKey: "audio",
  multiProvider: false,
  isDetectionType: true,
  properties: {
    [AudioProperty.Detected]: { type: "boolean" },
    [AudioProperty.Detections]: { type: "object", internal: true },
    [AudioProperty.Decibels]: { type: "number", unit: "dB" },
    [AudioProperty.LastTriggered]: { type: "number", internal: true }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/battery.js
var BatteryCapability;
(function(BatteryCapability2) {
  BatteryCapability2["LowBattery"] = "lowBattery";
  BatteryCapability2["Charging"] = "charging";
})(BatteryCapability || (BatteryCapability = {}));
var BatteryProperty;
(function(BatteryProperty2) {
  BatteryProperty2["Level"] = "level";
  BatteryProperty2["Charging"] = "charging";
  BatteryProperty2["Low"] = "low";
})(BatteryProperty || (BatteryProperty = {}));
var ChargingState;
(function(ChargingState2) {
  ChargingState2["NotChargeable"] = "NOT_CHARGEABLE";
  ChargingState2["NotCharging"] = "NOT_CHARGING";
  ChargingState2["Charging"] = "CHARGING";
  ChargingState2["Full"] = "FULL";
})(ChargingState || (ChargingState = {}));
var batteryMeta = defineSensor({
  type: SensorType.Battery,
  category: SensorCategory.Info,
  assignmentKey: "battery",
  multiProvider: false,
  isDetectionType: false,
  cameraBound: true,
  properties: {
    [BatteryProperty.Level]: { type: "number", min: 0, max: 100, unit: "%" },
    [BatteryProperty.Charging]: {
      type: "enum",
      values: {
        not_chargeable: ChargingState.NotChargeable,
        not_charging: ChargingState.NotCharging,
        charging: ChargingState.Charging,
        full: ChargingState.Full
      }
    },
    [BatteryProperty.Low]: { type: "boolean" }
  },
  shortcutable: true,
  propertyCapabilities: { [BatteryProperty.Charging]: BatteryCapability.Charging, [BatteryProperty.Low]: BatteryCapability.LowBattery },
  semantics: {
    domain: SensorDomain.Measurement,
    stateProperty: BatteryProperty.Level,
    commandProperty: BatteryProperty.Level,
    deviceClass: "battery",
    unit: "%",
    diagnostic: true
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/carbonDioxide.js
var CarbonDioxideProperty;
(function(CarbonDioxideProperty2) {
  CarbonDioxideProperty2["Current"] = "current";
})(CarbonDioxideProperty || (CarbonDioxideProperty = {}));
var carbonDioxideMeta = defineSensor({
  type: SensorType.CarbonDioxide,
  category: SensorCategory.Info,
  assignmentKey: "carbonDioxide",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [CarbonDioxideProperty.Current]: { type: "number", unit: "ppm", writable: true }
  },
  shortcutable: true,
  virtual: { properties: { [CarbonDioxideProperty.Current]: 20 } },
  semantics: {
    domain: SensorDomain.Measurement,
    stateProperty: CarbonDioxideProperty.Current,
    commandProperty: CarbonDioxideProperty.Current,
    deviceClass: "carbon_dioxide",
    unit: "ppm"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/carbonMonoxide.js
var CarbonMonoxideProperty;
(function(CarbonMonoxideProperty2) {
  CarbonMonoxideProperty2["Detected"] = "detected";
})(CarbonMonoxideProperty || (CarbonMonoxideProperty = {}));
var carbonMonoxideMeta = defineSensor({
  type: SensorType.CarbonMonoxide,
  category: SensorCategory.Sensor,
  assignmentKey: "carbonMonoxide",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [CarbonMonoxideProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: CarbonMonoxideProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [CarbonMonoxideProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: CarbonMonoxideProperty.Detected,
    commandProperty: CarbonMonoxideProperty.Detected,
    deviceClass: "carbon_monoxide"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/classifier.js
var ClassifierProperty;
(function(ClassifierProperty2) {
  ClassifierProperty2["Detected"] = "detected";
  ClassifierProperty2["Detections"] = "detections";
  ClassifierProperty2["Labels"] = "labels";
})(ClassifierProperty || (ClassifierProperty = {}));
var classifierMeta = defineSensor({
  type: SensorType.Classifier,
  category: SensorCategory.Sensor,
  assignmentKey: "classifier",
  multiProvider: true,
  isDetectionType: true,
  properties: {
    [ClassifierProperty.Detected]: { type: "boolean" },
    [ClassifierProperty.Detections]: { type: "object", internal: true },
    [ClassifierProperty.Labels]: { type: "object" }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/clip.js
var clipMeta = defineSensor({
  type: SensorType.Clip,
  category: SensorCategory.Sensor,
  assignmentKey: "clip",
  multiProvider: false,
  isDetectionType: true,
  properties: {},
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/cold.js
var ColdProperty;
(function(ColdProperty2) {
  ColdProperty2["Detected"] = "detected";
})(ColdProperty || (ColdProperty = {}));
var coldMeta = defineSensor({
  type: SensorType.Cold,
  category: SensorCategory.Sensor,
  assignmentKey: "cold",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [ColdProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: ColdProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [ColdProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: ColdProperty.Detected,
    commandProperty: ColdProperty.Detected,
    deviceClass: "cold"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/contact.js
var ContactProperty;
(function(ContactProperty2) {
  ContactProperty2["Detected"] = "detected";
})(ContactProperty || (ContactProperty = {}));
var contactMeta = defineSensor({
  type: SensorType.Contact,
  category: SensorCategory.Sensor,
  assignmentKey: "contact",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [ContactProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: ContactProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [ContactProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: ContactProperty.Detected,
    commandProperty: ContactProperty.Detected,
    deviceClass: "opening"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/detection.js
var OBJECT_DETECTION_LABELS = ["person", "vehicle", "animal"];
var DETECTION_LABELS = ["motion", ...OBJECT_DETECTION_LABELS, "audio"];

// node_modules/@camera.ui/sdk/dist/sensor/doorbell.js
var DoorbellProperty;
(function(DoorbellProperty2) {
  DoorbellProperty2["Ring"] = "ring";
})(DoorbellProperty || (DoorbellProperty = {}));
var doorbellMeta = defineSensor({
  type: SensorType.Doorbell,
  category: SensorCategory.Trigger,
  assignmentKey: "doorbell",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [DoorbellProperty.Ring]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: DoorbellProperty.Ring, value: true, sustained: false },
  virtual: { properties: { [DoorbellProperty.Ring]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: DoorbellProperty.Ring,
    commandProperty: DoorbellProperty.Ring,
    icon: "mdi:doorbell"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/face.js
var FaceProperty;
(function(FaceProperty2) {
  FaceProperty2["Detected"] = "detected";
  FaceProperty2["Detections"] = "detections";
  FaceProperty2["Identities"] = "identities";
})(FaceProperty || (FaceProperty = {}));
var faceMeta = defineSensor({
  type: SensorType.Face,
  category: SensorCategory.Sensor,
  assignmentKey: "face",
  multiProvider: false,
  isDetectionType: true,
  properties: {
    [FaceProperty.Detected]: { type: "boolean" },
    [FaceProperty.Detections]: { type: "object", internal: true },
    [FaceProperty.Identities]: { type: "object" }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/faceEmbedder.js
var faceEmbedderMeta = defineSensor({
  type: SensorType.FaceEmbedder,
  category: SensorCategory.Sensor,
  assignmentKey: "faceEmbedder",
  multiProvider: false,
  isDetectionType: true,
  properties: {},
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/garage.js
var GarageState;
(function(GarageState2) {
  GarageState2[GarageState2["Open"] = 0] = "Open";
  GarageState2[GarageState2["Closed"] = 1] = "Closed";
  GarageState2[GarageState2["Opening"] = 2] = "Opening";
  GarageState2[GarageState2["Closing"] = 3] = "Closing";
  GarageState2[GarageState2["Stopped"] = 4] = "Stopped";
})(GarageState || (GarageState = {}));
var GarageProperty;
(function(GarageProperty2) {
  GarageProperty2["CurrentState"] = "currentState";
  GarageProperty2["TargetState"] = "targetState";
  GarageProperty2["ObstructionDetected"] = "obstructionDetected";
})(GarageProperty || (GarageProperty = {}));
var garageMeta = defineSensor({
  type: SensorType.Garage,
  category: SensorCategory.Control,
  assignmentKey: "garage",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [GarageProperty.CurrentState]: {
      type: "enum",
      values: {
        open: GarageState.Open,
        closed: GarageState.Closed,
        opening: GarageState.Opening,
        closing: GarageState.Closing,
        stopped: GarageState.Stopped
      }
    },
    [GarageProperty.TargetState]: {
      type: "enum",
      values: { open: GarageState.Open, closed: GarageState.Closed },
      writable: true
    },
    [GarageProperty.ObstructionDetected]: { type: "boolean" }
  },
  shortcutable: true,
  cascadeTrigger: { property: GarageProperty.CurrentState, value: 0, sustained: true },
  virtual: { properties: { [GarageProperty.CurrentState]: 1, [GarageProperty.TargetState]: 1 } },
  semantics: {
    domain: SensorDomain.Cover,
    stateProperty: GarageProperty.CurrentState,
    commandProperty: GarageProperty.TargetState,
    deviceClass: "garage",
    states: {
      open: GarageState.Open,
      closed: GarageState.Closed,
      opening: GarageState.Opening,
      closing: GarageState.Closing,
      stopped: GarageState.Stopped
    }
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/gas.js
var GasProperty;
(function(GasProperty2) {
  GasProperty2["Detected"] = "detected";
})(GasProperty || (GasProperty = {}));
var gasMeta = defineSensor({
  type: SensorType.Gas,
  category: SensorCategory.Sensor,
  assignmentKey: "gas",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [GasProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: GasProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [GasProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: GasProperty.Detected,
    commandProperty: GasProperty.Detected,
    deviceClass: "gas"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/heat.js
var HeatProperty;
(function(HeatProperty2) {
  HeatProperty2["Detected"] = "detected";
})(HeatProperty || (HeatProperty = {}));
var heatMeta = defineSensor({
  type: SensorType.Heat,
  category: SensorCategory.Sensor,
  assignmentKey: "heat",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [HeatProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: HeatProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [HeatProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: HeatProperty.Detected,
    commandProperty: HeatProperty.Detected,
    deviceClass: "heat"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/humidity.js
var HumidityProperty;
(function(HumidityProperty2) {
  HumidityProperty2["Current"] = "current";
})(HumidityProperty || (HumidityProperty = {}));
var humidityMeta = defineSensor({
  type: SensorType.Humidity,
  category: SensorCategory.Info,
  assignmentKey: "humidity",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [HumidityProperty.Current]: { type: "number", min: 0, max: 100, unit: "%", writable: true }
  },
  shortcutable: true,
  virtual: { properties: { [HumidityProperty.Current]: 50 } },
  semantics: {
    domain: SensorDomain.Measurement,
    stateProperty: HumidityProperty.Current,
    commandProperty: HumidityProperty.Current,
    deviceClass: "humidity",
    unit: "%"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/illuminance.js
var IlluminanceProperty;
(function(IlluminanceProperty2) {
  IlluminanceProperty2["Current"] = "current";
})(IlluminanceProperty || (IlluminanceProperty = {}));
var illuminanceMeta = defineSensor({
  type: SensorType.Illuminance,
  category: SensorCategory.Info,
  assignmentKey: "illuminance",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [IlluminanceProperty.Current]: { type: "number", unit: "lx", writable: true }
  },
  shortcutable: true,
  virtual: { properties: { [IlluminanceProperty.Current]: 20 } },
  semantics: {
    domain: SensorDomain.Measurement,
    stateProperty: IlluminanceProperty.Current,
    commandProperty: IlluminanceProperty.Current,
    deviceClass: "illuminance",
    unit: "lx"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/leak.js
var LeakProperty;
(function(LeakProperty2) {
  LeakProperty2["Detected"] = "detected";
})(LeakProperty || (LeakProperty = {}));
var leakMeta = defineSensor({
  type: SensorType.Leak,
  category: SensorCategory.Sensor,
  assignmentKey: "leak",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [LeakProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: LeakProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [LeakProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: LeakProperty.Detected,
    commandProperty: LeakProperty.Detected,
    deviceClass: "moisture"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/licensePlate.js
var LicensePlateProperty;
(function(LicensePlateProperty2) {
  LicensePlateProperty2["Detected"] = "detected";
  LicensePlateProperty2["Detections"] = "detections";
  LicensePlateProperty2["Plates"] = "plates";
})(LicensePlateProperty || (LicensePlateProperty = {}));
var licensePlateMeta = defineSensor({
  type: SensorType.LicensePlate,
  category: SensorCategory.Sensor,
  assignmentKey: "licensePlate",
  multiProvider: false,
  isDetectionType: true,
  properties: {
    [LicensePlateProperty.Detected]: { type: "boolean" },
    [LicensePlateProperty.Detections]: { type: "object", internal: true },
    [LicensePlateProperty.Plates]: { type: "object" }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/light.js
var LightCapability;
(function(LightCapability2) {
  LightCapability2["Brightness"] = "brightness";
})(LightCapability || (LightCapability = {}));
var LightProperty;
(function(LightProperty2) {
  LightProperty2["On"] = "on";
  LightProperty2["Brightness"] = "brightness";
})(LightProperty || (LightProperty = {}));
var lightMeta = defineSensor({
  type: SensorType.Light,
  category: SensorCategory.Control,
  assignmentKey: "light",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [LightProperty.On]: { type: "boolean", writable: true },
    [LightProperty.Brightness]: { type: "number", min: 0, max: 100, unit: "%", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: LightProperty.On, value: true, sustained: true },
  propertyCapabilities: { [LightProperty.Brightness]: LightCapability.Brightness },
  virtual: {
    properties: { [LightProperty.On]: false, [LightProperty.Brightness]: 100 },
    capabilities: [LightCapability.Brightness]
  },
  semantics: {
    domain: SensorDomain.Light,
    stateProperty: LightProperty.On,
    commandProperty: LightProperty.On
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/lock.js
var LockState;
(function(LockState2) {
  LockState2[LockState2["Secured"] = 0] = "Secured";
  LockState2[LockState2["Unsecured"] = 1] = "Unsecured";
  LockState2[LockState2["Unknown"] = 2] = "Unknown";
})(LockState || (LockState = {}));
var LockProperty;
(function(LockProperty2) {
  LockProperty2["CurrentState"] = "currentState";
  LockProperty2["TargetState"] = "targetState";
})(LockProperty || (LockProperty = {}));
var lockMeta = defineSensor({
  type: SensorType.Lock,
  category: SensorCategory.Control,
  assignmentKey: "lock",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [LockProperty.CurrentState]: {
      type: "enum",
      values: { secured: LockState.Secured, unsecured: LockState.Unsecured, unknown: LockState.Unknown }
    },
    [LockProperty.TargetState]: {
      type: "enum",
      values: { secured: LockState.Secured, unsecured: LockState.Unsecured },
      writable: true
    }
  },
  shortcutable: true,
  cascadeTrigger: { property: LockProperty.CurrentState, value: 1, sustained: true },
  virtual: { properties: { [LockProperty.CurrentState]: 0, [LockProperty.TargetState]: 0 } },
  semantics: {
    domain: SensorDomain.Lock,
    stateProperty: LockProperty.CurrentState,
    commandProperty: LockProperty.TargetState,
    states: { locked: LockState.Secured, unlocked: LockState.Unsecured }
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/motion.js
var MotionProperty;
(function(MotionProperty2) {
  MotionProperty2["Detected"] = "detected";
  MotionProperty2["Detections"] = "detections";
  MotionProperty2["Blocked"] = "blocked";
  MotionProperty2["LastTriggered"] = "lastTriggered";
})(MotionProperty || (MotionProperty = {}));
var motionMeta = defineSensor({
  type: SensorType.Motion,
  category: SensorCategory.Sensor,
  assignmentKey: "motion",
  multiProvider: false,
  isDetectionType: true,
  properties: {
    [MotionProperty.Detected]: { type: "boolean" },
    [MotionProperty.Detections]: { type: "object", internal: true },
    [MotionProperty.Blocked]: { type: "boolean", internal: true },
    [MotionProperty.LastTriggered]: { type: "number", internal: true }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/object.js
var ObjectProperty;
(function(ObjectProperty2) {
  ObjectProperty2["Detected"] = "detected";
  ObjectProperty2["Detections"] = "detections";
  ObjectProperty2["Labels"] = "labels";
  ObjectProperty2["StaticDetections"] = "staticDetections";
})(ObjectProperty || (ObjectProperty = {}));
var objectMeta = defineSensor({
  type: SensorType.Object,
  category: SensorCategory.Sensor,
  assignmentKey: "object",
  multiProvider: false,
  isDetectionType: true,
  properties: {
    [ObjectProperty.Detected]: { type: "boolean" },
    [ObjectProperty.Detections]: { type: "object", internal: true },
    [ObjectProperty.Labels]: { type: "object" },
    [ObjectProperty.StaticDetections]: { type: "object", internal: true }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/objectAssist.js
var objectAssistMeta = defineSensor({
  type: SensorType.ObjectAssist,
  category: SensorCategory.Sensor,
  assignmentKey: "objectAssist",
  multiProvider: false,
  isDetectionType: true,
  properties: {},
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/occupancy.js
var OccupancyProperty;
(function(OccupancyProperty2) {
  OccupancyProperty2["Detected"] = "detected";
})(OccupancyProperty || (OccupancyProperty = {}));
var occupancyMeta = defineSensor({
  type: SensorType.Occupancy,
  category: SensorCategory.Sensor,
  assignmentKey: "occupancy",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [OccupancyProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: OccupancyProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [OccupancyProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: OccupancyProperty.Detected,
    commandProperty: OccupancyProperty.Detected,
    deviceClass: "occupancy"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/personEmbedder.js
var personEmbedderMeta = defineSensor({
  type: SensorType.PersonEmbedder,
  category: SensorCategory.Sensor,
  assignmentKey: "personEmbedder",
  multiProvider: false,
  isDetectionType: true,
  properties: {},
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/power.js
var PowerProperty;
(function(PowerProperty2) {
  PowerProperty2["Detected"] = "detected";
})(PowerProperty || (PowerProperty = {}));
var powerMeta = defineSensor({
  type: SensorType.Power,
  category: SensorCategory.Sensor,
  assignmentKey: "power",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [PowerProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: PowerProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [PowerProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: PowerProperty.Detected,
    commandProperty: PowerProperty.Detected,
    deviceClass: "power"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/problem.js
var ProblemProperty;
(function(ProblemProperty2) {
  ProblemProperty2["Detected"] = "detected";
})(ProblemProperty || (ProblemProperty = {}));
var problemMeta = defineSensor({
  type: SensorType.Problem,
  category: SensorCategory.Sensor,
  assignmentKey: "problem",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [ProblemProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: ProblemProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [ProblemProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: ProblemProperty.Detected,
    commandProperty: ProblemProperty.Detected,
    deviceClass: "problem"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/ptz.js
var PTZCapability;
(function(PTZCapability2) {
  PTZCapability2["Pan"] = "pan";
  PTZCapability2["Tilt"] = "tilt";
  PTZCapability2["Zoom"] = "zoom";
  PTZCapability2["Presets"] = "presets";
  PTZCapability2["Home"] = "home";
  PTZCapability2["RelativeMove"] = "relativeMove";
  PTZCapability2["AbsolutePosition"] = "absolutePosition";
  PTZCapability2["VelocityControl"] = "velocityControl";
})(PTZCapability || (PTZCapability = {}));
var PTZProperty;
(function(PTZProperty2) {
  PTZProperty2["Position"] = "position";
  PTZProperty2["Moving"] = "moving";
  PTZProperty2["Presets"] = "presets";
  PTZProperty2["Velocity"] = "velocity";
  PTZProperty2["TargetPreset"] = "targetPreset";
  PTZProperty2["RelativeMove"] = "relativeMove";
  PTZProperty2["Home"] = "home";
})(PTZProperty || (PTZProperty = {}));
var ptzMeta = defineSensor({
  type: SensorType.PTZ,
  category: SensorCategory.Control,
  assignmentKey: "ptz",
  multiProvider: false,
  isDetectionType: false,
  cameraBound: true,
  properties: {
    [PTZProperty.Position]: { type: "object", writable: true, keys: ["pan", "tilt", "zoom"] },
    [PTZProperty.Moving]: { type: "boolean" },
    [PTZProperty.Presets]: { type: "object" },
    [PTZProperty.Velocity]: { type: "object", writable: true, internal: true },
    [PTZProperty.TargetPreset]: { type: "string", writable: true },
    [PTZProperty.RelativeMove]: { type: "object", writable: true, internal: true },
    [PTZProperty.Home]: { type: "boolean", writable: true, internal: true }
  },
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/securitySystem.js
var SecuritySystemState;
(function(SecuritySystemState2) {
  SecuritySystemState2[SecuritySystemState2["StayArm"] = 0] = "StayArm";
  SecuritySystemState2[SecuritySystemState2["AwayArm"] = 1] = "AwayArm";
  SecuritySystemState2[SecuritySystemState2["NightArm"] = 2] = "NightArm";
  SecuritySystemState2[SecuritySystemState2["Disarmed"] = 3] = "Disarmed";
  SecuritySystemState2[SecuritySystemState2["AlarmTriggered"] = 4] = "AlarmTriggered";
})(SecuritySystemState || (SecuritySystemState = {}));
var SecuritySystemProperty;
(function(SecuritySystemProperty2) {
  SecuritySystemProperty2["CurrentState"] = "currentState";
  SecuritySystemProperty2["TargetState"] = "targetState";
})(SecuritySystemProperty || (SecuritySystemProperty = {}));
var securitySystemMeta = defineSensor({
  type: SensorType.SecuritySystem,
  category: SensorCategory.Control,
  assignmentKey: "securitySystem",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [SecuritySystemProperty.CurrentState]: {
      type: "enum",
      values: {
        stay_arm: SecuritySystemState.StayArm,
        away_arm: SecuritySystemState.AwayArm,
        night_arm: SecuritySystemState.NightArm,
        disarmed: SecuritySystemState.Disarmed,
        alarm_triggered: SecuritySystemState.AlarmTriggered
      }
    },
    [SecuritySystemProperty.TargetState]: {
      type: "enum",
      values: {
        stay_arm: SecuritySystemState.StayArm,
        away_arm: SecuritySystemState.AwayArm,
        night_arm: SecuritySystemState.NightArm,
        disarmed: SecuritySystemState.Disarmed
      },
      writable: true
    }
  },
  shortcutable: true,
  cascadeTrigger: { property: SecuritySystemProperty.CurrentState, value: 4, sustained: true },
  virtual: { properties: { [SecuritySystemProperty.CurrentState]: 3, [SecuritySystemProperty.TargetState]: 3 } },
  semantics: {
    domain: SensorDomain.Alarm,
    stateProperty: SecuritySystemProperty.CurrentState,
    commandProperty: SecuritySystemProperty.TargetState,
    states: {
      armed_home: SecuritySystemState.StayArm,
      armed_away: SecuritySystemState.AwayArm,
      armed_night: SecuritySystemState.NightArm,
      disarmed: SecuritySystemState.Disarmed,
      triggered: SecuritySystemState.AlarmTriggered
    }
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/segmenter.js
var segmenterMeta = defineSensor({
  type: SensorType.Segmenter,
  category: SensorCategory.Sensor,
  assignmentKey: "segmenter",
  multiProvider: false,
  isDetectionType: true,
  properties: {},
  semantics: null
});

// node_modules/@camera.ui/sdk/dist/sensor/siren.js
var SirenCapability;
(function(SirenCapability2) {
  SirenCapability2["Volume"] = "volume";
})(SirenCapability || (SirenCapability = {}));
var SirenProperty;
(function(SirenProperty2) {
  SirenProperty2["Active"] = "active";
  SirenProperty2["Volume"] = "volume";
})(SirenProperty || (SirenProperty = {}));
var sirenMeta = defineSensor({
  type: SensorType.Siren,
  category: SensorCategory.Control,
  assignmentKey: "siren",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [SirenProperty.Active]: { type: "boolean", writable: true },
    [SirenProperty.Volume]: { type: "number", min: 0, max: 100, unit: "%", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: SirenProperty.Active, value: true, sustained: true },
  propertyCapabilities: { [SirenProperty.Volume]: SirenCapability.Volume },
  virtual: { properties: { [SirenProperty.Active]: false, [SirenProperty.Volume]: 100 }, capabilities: [SirenCapability.Volume] },
  semantics: {
    domain: SensorDomain.Siren,
    stateProperty: SirenProperty.Active,
    commandProperty: SirenProperty.Active
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/smoke.js
var SmokeProperty;
(function(SmokeProperty2) {
  SmokeProperty2["Detected"] = "detected";
})(SmokeProperty || (SmokeProperty = {}));
var smokeMeta = defineSensor({
  type: SensorType.Smoke,
  category: SensorCategory.Sensor,
  assignmentKey: "smoke",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [SmokeProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: SmokeProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [SmokeProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: SmokeProperty.Detected,
    commandProperty: SmokeProperty.Detected,
    deviceClass: "smoke"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/switch.js
var SwitchProperty;
(function(SwitchProperty2) {
  SwitchProperty2["On"] = "on";
})(SwitchProperty || (SwitchProperty = {}));
var switchMeta = defineSensor({
  type: SensorType.Switch,
  category: SensorCategory.Control,
  assignmentKey: "switch",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [SwitchProperty.On]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: SwitchProperty.On, value: true, sustained: true },
  virtual: { properties: { [SwitchProperty.On]: false } },
  semantics: {
    domain: SensorDomain.Switch,
    stateProperty: SwitchProperty.On,
    commandProperty: SwitchProperty.On
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/tamper.js
var TamperProperty;
(function(TamperProperty2) {
  TamperProperty2["Detected"] = "detected";
})(TamperProperty || (TamperProperty = {}));
var tamperMeta = defineSensor({
  type: SensorType.Tamper,
  category: SensorCategory.Sensor,
  assignmentKey: "tamper",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [TamperProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: TamperProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [TamperProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: TamperProperty.Detected,
    commandProperty: TamperProperty.Detected,
    deviceClass: "tamper"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/temperature.js
var TemperatureProperty;
(function(TemperatureProperty2) {
  TemperatureProperty2["Current"] = "current";
})(TemperatureProperty || (TemperatureProperty = {}));
var temperatureMeta = defineSensor({
  type: SensorType.Temperature,
  category: SensorCategory.Info,
  assignmentKey: "temperature",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [TemperatureProperty.Current]: { type: "number", unit: "\xB0C", writable: true }
  },
  shortcutable: true,
  virtual: { properties: { [TemperatureProperty.Current]: 20 } },
  semantics: {
    domain: SensorDomain.Measurement,
    stateProperty: TemperatureProperty.Current,
    commandProperty: TemperatureProperty.Current,
    deviceClass: "temperature",
    unit: "\xB0C"
  }
});

// node_modules/@camera.ui/sdk/dist/sensor/vibration.js
var VibrationProperty;
(function(VibrationProperty2) {
  VibrationProperty2["Detected"] = "detected";
})(VibrationProperty || (VibrationProperty = {}));
var vibrationMeta = defineSensor({
  type: SensorType.Vibration,
  category: SensorCategory.Sensor,
  assignmentKey: "vibration",
  multiProvider: true,
  isDetectionType: false,
  properties: {
    [VibrationProperty.Detected]: { type: "boolean", writable: true }
  },
  shortcutable: true,
  cascadeTrigger: { property: VibrationProperty.Detected, value: true, sustained: true },
  virtual: { properties: { [VibrationProperty.Detected]: false } },
  semantics: {
    domain: SensorDomain.Binary,
    stateProperty: VibrationProperty.Detected,
    commandProperty: VibrationProperty.Detected,
    deviceClass: "vibration"
  }
});

// contract.ts
var contract = {
  name: "Telegram",
  role: PluginRole.Service,
  provides: [],
  consumes: [],
  interfaces: [PluginInterface.Notifier]
};
var contract_default = contract;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  contract
});
